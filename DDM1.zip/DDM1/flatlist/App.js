import { StatusBar } from 'expo-status-bar';
import {StyleSheet,Text, View, FlatList, Button, Image, Modal, Pressable} from 'react-native';
import { useState } from 'react';


export default function App() {
  const produto = [
    {
      id: '01',
      foto: require('./img/produto1.jpg'),
      descricao:
        'Oferece alta proteção contra os raios UVA e UVB, ajudando a prevenir queimaduras, manchas e o envelhecimento precoce da pele. Possui textura leve, rápida absorção e é ideal para uso diário, mantendo a pele protegida e saudável.',
      fabricante: 'Cosnori',
      produto: 'Protetor Solar',
    },
    {
      id: '02',
      foto: require('./img/produto2.jpg'),
      descricao:
        'Potente antioxidante que ajuda a iluminar a pele, uniformizar o tom e reduzir sinais de cansaço. Também auxilia na produção de colágeno, deixando a pele mais firme, radiante e com aparência revitalizada.',
      fabricante: 'Gymbiotika',
      produto: 'Vitamina C',
    },
    {
      id: '03',
      foto: require('./img/produto3.jpg'),
      descricao: 'Hidrata profundamente a pele, promovendo maciez e elasticidade. Sua fórmula leve ajuda a reter a umidade, deixando o corpo com toque suave, aparência saudável e sensação prolongada de hidratação.',
      fabricante: 'Osea',
      produto: 'Sérum Corporal',
    },
  ];

  const [modalVisible, setModalVisible] = useState(false);
  const [descricaoAtual, setDescricaoAtual] = useState('');

  return (
    <View style={styles.container}>
      <FlatList
        data={produto}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => {
          return (
            <View style={styles.card}>
              <Text style={styles.text}>ID: {item.id}</Text>
              <Text style={styles.text}>Produto: {item.produto}</Text>
              <Text style={styles.text}>Fabricante: {item.fabricante}</Text>

              <Image
                source={item.foto}
                style={styles.imagem}
                resizeMode="cover"
              />

              <Button
                title="Descrição"
                color="#FF69B4"
                onPress={() => {
                  setDescricaoAtual(item.descricao);
                  setModalVisible(true);
                }}
              />
            </View>
          );
        }}
      />

      <Modal transparent={true} visible={modalVisible}>
        <View style={styles.modalContainer}>
          <View style={styles.modalView}>
            <Text
              style={{ fontWeight: 'bold', fontSize: 20, marginBottom: 10 }}>
              Descrição
            </Text>

            <Text style={styles.modalTexto}>{descricaoAtual}</Text>

            <Pressable
              style={styles.botaoFechar}
              onPress={() => setModalVisible(false)}>
              <Text style={{ color: '#fff', fontWeight: 'bold' }}>Fechar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignContent:'center',
    flex: 1,
    backgroundColor: '#104E8B',
    padding: 8,
  },
  
  listContent: {
    alignItems: 'center',
    paddingVertical: 20,
  },

  card: {
    width: 300,
    height: 350,
    margin: 60,
    padding: 10,
    backgroundColor: '#87CEFA',
    borderRadius: 10,
    elevation: 3,
  },

  text: {
    fontSize: 16,
    marginBottom: 3,
  },

  imagem: {
    width: '100%',
    height: 205,
    borderRadius: 10,
    marginVertical: 8,
  },

  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
  },

  modalView: {
    backgroundColor: '#fff',
    padding: 25,
    borderRadius: 15,
    width: '85%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    margin: 20
  },

  modalTexto: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'justify',
    lineHeight: 24,
    color: '#333',
  },

  botaoFechar: {
    backgroundColor:'#FF69B4',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
});

